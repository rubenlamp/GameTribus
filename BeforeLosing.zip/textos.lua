LANG = 'ES'
DIAL = {}
DIAL['ES'] = {
    --// definimos nombres de as cosas...
    game_name = 'B E F O R E ~ L O S I N G',
    gui_once_was_a_king =
[[Una vez existio un rey
bastante distraido y torpe,
quien perdio algo muy importante
y que estaba dispuesto a cualquier
cosa para recuperarlo]],
    gui_new_game = 'Juego Nuevo',
    gui_exit = 'Salir',
    gui_ready = '¿Estas listo?',
    gui_return = 'Regresar',
    gui_opt_atk = 'Atacar',
    gui_opt_dial = 'Dialogar',
    gui_opt_ret = 'Dejame Pensarlo',
    gui_dial_is_susses = '¡Toma Notas Churchill!\n~ EXITO ~',
    gui_dial_is_fail = 'Esas clases de retorica te estafaron.\n~ FRACASO ~ ',
    gui_dial_sum = 'Los Numeros Deben Sumar',
    gui_battle_gonna = '¡La batalla esta por comenzar!',
    gui_atk_inst = 
[[Manten el circulo dentro del rectangulo
Para mover hacia adelante da click varias veces
Para ir hacia atras no hagas nada]],
    gui_atk_is_susses = 'No somos machos, ¡Pero sí somos muchos!\n~ EXITO ~',
    gui_atk_is_fail = 'Nunca ataques con el estomago vacio\n~ FRACASO ~ '
    
    }